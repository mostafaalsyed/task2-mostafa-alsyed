class NetworkSettings {
  static const String baseUrl = "https://dummyjson.com/";
}
