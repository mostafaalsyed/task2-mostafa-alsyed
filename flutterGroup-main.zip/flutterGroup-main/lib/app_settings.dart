import 'package:flutter/material.dart';

class AppSettings {
  static const String phoneNumberSharedPrefsKey = "user_phone_number";
  static Color mainAppColor = Colors.blue;
}
