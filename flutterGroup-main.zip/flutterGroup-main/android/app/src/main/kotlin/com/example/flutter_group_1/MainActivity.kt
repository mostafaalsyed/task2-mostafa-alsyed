package com.example.flutter_group_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
